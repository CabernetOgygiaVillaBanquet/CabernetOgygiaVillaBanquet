/// Below are commented asserts.
/// Remove a comment from these lines as you finish the appropriate function to test its correctness.
/// If uncommented asserts work correctly, then there will not be any output.
/// Don't modify assert expressions - only uncomment the lines when a particular function is implemented!

#define _USE_MATH_DEFINES
#include <cmath>
#include <cassert>
#include <iostream>
#include "Cone.hpp"
    
int main()
{
    constexpr double epsil{ 0.05 };

    /// Task 3: Cone instance creation
//    Cone c0{ M_PI, 5.0 }; // base height and base radius

    /// Task 4: Retrieve radius
//    assert(std::abs(5.0 - c0.radius()) < epsil);
    
    /// Task 4: Retrieve height
//    assert(std::abs(M_PI - c0.height()) < epsil);

    /// Task 5: Retrieve volume
//    assert(std::abs(82.25 - c0.volume()) < epsil);
    
    /// Task 5: Retrieve base area
//    assert(std::abs(78.54 - c0.base_area()) < epsil);

    /// Task 5: Retrieve lateral area
//    assert(std::abs(92.76 - c0.lateral_area()) < epsil);

    /// Task 5: Retrieve total surface area
//    assert(std::abs(171.30 - c0.total_area()) < epsil);

    std::cout << "OK\n";

    return 0;
}