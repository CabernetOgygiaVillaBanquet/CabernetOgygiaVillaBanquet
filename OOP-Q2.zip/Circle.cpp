/// Don't modify anything in this input file!

#include "Circle.hpp"
