/// Add required C++ statements to declare and define the class Cone

