/// Add required C++ statements to define the class Cone

#include "Cone.hpp"
